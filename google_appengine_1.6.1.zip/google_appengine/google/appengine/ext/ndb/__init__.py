"""NDB -- A new datastore API for the Google App Engine Python runtime."""

__version__ = '0.9.3'
